# Vinland_ComputerGraphics
A GUI project for computer graphics created with opengl and glut. the project contain a river, on top of the river there is a bridge. some car drive through the bridge. 
there is some city building, tree and sun. there is rain effect in the project. the tree will grow slowly depending on weather. The sun and moon will be the timer with those
change the weather, day and night will be occurd. 